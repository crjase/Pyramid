# TODO: Use threading to split the work into quarters, then add the values together in the correct order, to be writted to output.txt.

import time
import threading


# base width -- until 1
try:
    base = int(input("Base Value: "))
except ValueError:
    print("Base Value must be an integer, default value will be used in place.")
    time.sleep(3)
    base = 100


# Store base for later
storedBase = base

# base decrese amount
decrease = 2
# margin from wall
margin = 0
# Get Loop Count
looped = 0

# Store output strings
outputData = ""


# Apend output to a file
with open("Output.txt", "w") as output:

    # Loop until we reach the specified base width
    for i in range(base):

        # Set margin from wall
        for ii in range(margin):
            outputData += " "

        # Print the base width which is decreased per loop
        for iii in range(base):
            outputData += "1"


        base -= decrease
        margin += 1
        outputData += "\n"
        looped += 1

        # Loading Display : Calculate the completion
        print(f"Processing: {looped}/{storedBase}")


    # Finished. Return the output file
    output.write(outputData)
