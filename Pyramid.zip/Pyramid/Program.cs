﻿using System;
using System.Text;


namespace Pyramid
{
    internal class Program
    {
        static long baseNum;
        static long storedBaseNum;

        // Base decrease amount
        static int decrease = 2;
        // Margin from wall
        static int margin = 0;
        // Get loop count
        static int looped = 0;
        // Limit between writing
        static int count = 0;

        // Store output as a mutable string
        static StringBuilder sb = new StringBuilder();


        static void Main(string[] args)
        {
            try
            {
                Console.Write("Base Value: ");
                string ?value = Console.ReadLine();

                baseNum = Int64.Parse(value);
            }
            catch (System.FormatException)
            {
                Console.WriteLine("Invalid Base Value...");
                Thread.Sleep(3000);
                Main(args);
                return;
            }

            storedBaseNum = baseNum;
            Process();
        }

        static void Process()
        {
            for (int i = 0; i < storedBaseNum; i++)
            {
                // Set margin from wall
                for (int ii = 0; ii < margin; ii++)
                    sb.Append(" ");

                // Base width ++
                for (int iii = 0; iii < baseNum; iii++)
                    sb.Append("1");

                // Calculation
                baseNum -= decrease;
                margin ++;
                sb.Append("\n");
                looped ++;
                count ++;

                // Makes the text invisible for some reason. TODO: Fix later.
                // if (count > 1000)
                // {
                //     File.WriteAllText("Output.txt", sb.ToString());
                //     sb.Clear();
                //     count = 0;
                // }

                // Completion Status
                Console.WriteLine($"Processing: {looped}/{storedBaseNum} - Count:{count}");
            }


            // Output everything to a text file.
            File.WriteAllText("Output.txt", sb.ToString());
        }
    }
}