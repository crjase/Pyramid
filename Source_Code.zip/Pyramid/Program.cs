﻿using System;
using System.Text;


namespace Pyramid
{
    internal class Program
    {
        static long baseNum;
        static long storedBaseNum;

        // Base decrease amount
        static int decrease = 2;
        // Margin from wall
        static int margin = 0;
        // Get loop count
        static int looped = 0;
        // Limit between writing
        static int count = 0;
        // Limit
        static int limit;

        // Store output as a mutable string
        static StringBuilder sb = new StringBuilder();


        static void Main(string[] args)
        {
            Console.Write("Base Value: ");
            string ?value = Console.ReadLine();

            long longValue;
            bool success = long.TryParse(value, out longValue);

            if (success)
            {
                baseNum = longValue;

                // Clear or make empty existing output file before starting
                File.WriteAllText("Output.txt", "");

                // The only argument used
                limit = int.Parse(args[0]);

                storedBaseNum = baseNum;
                Process();
            }
            else
            {
                Console.WriteLine($"Attempted conversion of {value ?? "<null>"} failed.");
                Console.WriteLine("Invalid Base Value...");
                Thread.Sleep(3000);
                Main(args);
                return;
            }
        }

        static void Process()
        {
            for (int i = 0; i < storedBaseNum; i++)
            {
                // Set margin from wall
                for (int ii = 0; ii < margin; ii++)
                    sb.Append(" ");

                // Base width ++
                for (int iii = 0; iii < baseNum; iii++)
                    sb.Append("1");

                // Calculation
                baseNum -= decrease;
                margin ++;
                sb.Append("\n");
                looped ++;
                count ++;

                if (count > limit && limit > 0)
                {
                    File.AppendAllText("Output.txt", sb.ToString());
                    sb.Clear();
                    count = 0;
                }

                // Completion Status
                Console.WriteLine($"Processing: {looped}/{storedBaseNum} - Count:{count}");
            }


            // Output everything to a text file.
            File.AppendAllText("Output.txt", sb.ToString());
        }
    }
}